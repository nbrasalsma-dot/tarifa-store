import { Download, FileArchive, ExternalLink } from "lucide-react";
import Link from "next/link";

export default function DownloadPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-100 flex items-center justify-center p-4" dir="rtl">
      <div className="max-w-2xl w-full">
        {/* الشعار */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-rose-600 mb-2">تَرِفَة</h1>
          <p className="text-gray-600">متجر إكسسوارات وعطور نسائية فاخرة</p>
        </div>

        {/* بطاقة التحميل */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 text-center">
          <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileArchive className="w-10 h-10 text-rose-600" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-2">تحميل ملفات الموقع</h2>
          <p className="text-gray-500 mb-6">الملفات الكاملة لمتجر تَرِفَة جاهزة للنشر</p>
          
          {/* معلومات الملف */}
          <div className="bg-gray-50 rounded-xl p-4 mb-6 text-right">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-500">اسم الملف:</span>
              <span className="font-mono text-sm">tarifa-store-download.tar.gz</span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-500">الحجم:</span>
              <span className="font-bold text-green-600">~900 KB</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">الصيغة:</span>
              <span>ملف مضغوط (.tar.gz)</span>
            </div>
          </div>

          {/* زر التحميل */}
          <a 
            href="/tarifa-store-download.tar.gz"
            download
            className="inline-flex items-center gap-3 bg-rose-600 hover:bg-rose-700 text-white font-bold py-4 px-8 rounded-2xl text-xl transition-all transform hover:scale-105 shadow-lg"
          >
            <Download className="w-6 h-6" />
            تحميل الملفات
          </a>

          <p className="text-gray-400 text-sm mt-4">
            ⬇️ اضغط على الزر لبدء التحميل
          </p>

          {/* ما بعد التحميل */}
          <div className="mt-8 pt-6 border-t border-gray-100 text-right">
            <h3 className="font-bold text-gray-700 mb-3">📋 بعد التحميل:</h3>
            <ol className="text-gray-600 space-y-2 text-sm">
              <li>1. فك الضغط عن الملف</li>
              <li>2. ارفع الملفات إلى استضافتك</li>
              <li>3. غيّر اسم <code className="bg-gray-100 px-1 rounded">.env.example</code> إلى <code className="bg-gray-100 px-1 rounded">.env</code></li>
              <li>4. شغّل: <code className="bg-gray-100 px-1 rounded">npm install</code></li>
              <li>5. شغّل: <code className="bg-gray-100 px-1 rounded">npm run build</code></li>
              <li>6. شغّل: <code className="bg-gray-100 px-1 rounded">npm run start</code></li>
            </ol>
          </div>
        </div>

        {/* رابط العودة */}
        <div className="text-center mt-6">
          <Link href="/" className="inline-flex items-center gap-2 text-rose-600 hover:text-rose-700">
            <ExternalLink className="w-4 h-4" />
            العودة للمتجر
          </Link>
        </div>
      </div>
    </div>
  );
}
