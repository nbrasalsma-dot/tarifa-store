import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

/**
 * Generate ImageKit authentication signature
 * This is called before uploading images to get a secure signature
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fileName } = body;

    const privateKey = process.env.IMAGEKIT_PRIVATE_KEY;
    const publicKey = process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY;

    // If ImageKit is not configured, return error
    if (!privateKey || !publicKey) {
      return NextResponse.json({
        error: "ImageKit not configured",
        message: "Please add IMAGEKIT_PRIVATE_KEY and NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY to your environment variables",
      }, { status: 500 });
    }

    // Generate authentication parameters
    const expire = Math.floor(Date.now() / 1000) + 2400; // 40 minutes from now
    const token = crypto.randomBytes(16).toString("hex");
    
    // Create signature
    const signatureInput = `token=${token}&expire=${expire}&privateKey=${privateKey}`;
    const signature = crypto.createHash("sha1").update(signatureInput).digest("hex");

    return NextResponse.json({
      signature,
      expire,
      token,
      publicKey,
    });

  } catch (error) {
    console.error("Upload auth error:", error);
    return NextResponse.json({
      error: "Failed to generate upload authentication",
    }, { status: 500 });
  }
}
