/**
 * Image Upload Service
 * Supports: ImageKit, Base64, and URL
 * 
 * When deploying to Vercel, add these environment variables:
 * - IMAGEKIT_PUBLIC_KEY
 * - IMAGEKIT_PRIVATE_KEY
 * - IMAGEKIT_URL_ENDPOINT
 */

// Image upload result
export interface UploadResult {
  success: boolean;
  url?: string;
  error?: string;
}

/**
 * Upload image to ImageKit (cloud storage)
 * Falls back to base64 if ImageKit is not configured
 */
export async function uploadImage(file: File): Promise<UploadResult> {
  // Check file size (max 5MB)
  if (file.size > 5 * 1024 * 1024) {
    return { success: false, error: "حجم الملف كبير جداً (الحد الأقصى 5MB)" };
  }

  // Check file type
  const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
  if (!allowedTypes.includes(file.type)) {
    return { success: false, error: "نوع الملف غير مدعوم (JPEG, PNG, WebP, GIF)" };
  }

  const publicKey = process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY;
  const privateKey = process.env.IMAGEKIT_PRIVATE_KEY;
  const urlEndpoint = process.env.NEXT_PUBLIC_IMAGEKIT_URL_ENDPOINT;

  // If ImageKit is configured, use it
  if (publicKey && privateKey && urlEndpoint) {
    return uploadToImageKit(file, publicKey, privateKey, urlEndpoint);
  }

  // Otherwise, convert to base64 (for development)
  return convertToBase64(file);
}

/**
 * Upload to ImageKit cloud storage
 */
async function uploadToImageKit(
  file: File,
  publicKey: string,
  privateKey: string,
  urlEndpoint: string
): Promise<UploadResult> {
  try {
    // Generate authentication signature (server-side)
    const authResponse = await fetch("/api/upload/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileName: file.name }),
    });

    if (!authResponse.ok) {
      throw new Error("Failed to get upload authentication");
    }

    const authData = await authResponse.json();

    // Create form data
    const formData = new FormData();
    formData.append("file", file);
    formData.append("fileName", `tarifa-${Date.now()}-${file.name}`);
    formData.append("signature", authData.signature);
    formData.append("expire", authData.expire);
    formData.append("token", authData.token);
    formData.append("publicKey", publicKey);

    // Upload to ImageKit
    const uploadResponse = await fetch("https://upload.imagekit.io/api/v1/files/upload", {
      method: "POST",
      body: formData,
    });

    if (!uploadResponse.ok) {
      throw new Error("Upload failed");
    }

    const result = await uploadResponse.json();

    return {
      success: true,
      url: result.url,
    };
  } catch (error) {
    console.error("ImageKit upload error:", error);
    return {
      success: false,
      error: "فشل رفع الصورة، جاري استخدام طريقة بديلة...",
    };
  }
}

/**
 * Convert file to base64 (fallback for development)
 */
async function convertToBase64(file: File): Promise<UploadResult> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      resolve({
        success: true,
        url: reader.result as string,
      });
    };
    reader.onerror = () => {
      resolve({
        success: false,
        error: "فشل قراءة الملف",
      });
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Validate image URL
 */
export function isValidImageUrl(url: string): boolean {
  try {
    new URL(url);
    return /\.(jpg|jpeg|png|webp|gif|svg)$/i.test(url);
  } catch {
    return false;
  }
}

/**
 * Get optimized image URL with ImageKit transformations
 */
export function getOptimizedImageUrl(
  url: string,
  options: {
    width?: number;
    height?: number;
    quality?: number;
  } = {}
): string {
  const { width, height, quality = 80 } = options;
  
  // If it's an ImageKit URL, add transformations
  if (url.includes("imagekit.io")) {
    const params = [];
    if (width) params.push(`w-${width}`);
    if (height) params.push(`h-${height}`);
    params.push(`q-${quality}`);
    
    if (params.length > 0) {
      const separator = url.includes("?") ? "&" : "?";
      return `${url}${separator}tr=${params.join(",")}`;
    }
  }
  
  return url;
}
